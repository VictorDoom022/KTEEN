
package mytruehomework;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

import java.io.*; //File class
import java.util.*; //Scanner

public class MathQuizPanel extends Application{
    Button btnGetQuestion = new Button("Get Question"),
           btnSubmit = new Button("Submit"),
           btnExit = new Button("Exit"),
           btnStart = new Button("Start");
    
    RadioButton rbAddition = new RadioButton("Addition"),
                rbSubtraction = new RadioButton("Subtraction"),
                rbMultiplication = new RadioButton("Multiplication"),
                rbDivision = new RadioButton("Division");
    
    TextField tf = new TextField(),
              tfAQ = new TextField(),
              tfCA = new TextField();
    TextArea ta = new TextArea();
             
    
    Label lbEnterAnswer = new Label("Enter answer"),
          lbAProblem = new Label("a problem"),
          lbCountDown = new Label("CountDown"),
          lbAnswerQ = new Label("Answered Question :"),
          lbCorrectA = new Label("Correct Answer:");
    
    AProblem AProblem;
    int answerQuestion = 0;
    int correctAnswer = 0;
    Stage Window;
    Scene scene1,scene2;
    double ans ;
    public void start(Stage primaryStage){
        Window = primaryStage;
        
        
        HBox ROW1 = new HBox();
        ROW1.setSpacing(20);
        ROW1.setAlignment(Pos.CENTER_LEFT);
        ROW1.getChildren().addAll(rbAddition,rbSubtraction,rbMultiplication,rbDivision);
        ROW1.setPadding(new Insets(0,0,10,0));
        
        ToggleGroup group = new ToggleGroup();
    	rbAddition.setToggleGroup(group);
    	rbSubtraction.setToggleGroup(group);
    	rbMultiplication.setToggleGroup(group);
        rbDivision.setToggleGroup(group);
        rbAddition.setSelected(true);
        
        
        HBox ROW2 = new HBox();
        ROW2.setSpacing(20);
        ROW2.setAlignment(Pos.CENTER_LEFT);
        ROW2.getChildren().addAll(btnStart,btnGetQuestion,lbCountDown,lbAProblem);
        ROW2.setPadding(new Insets(0,0,10,0));
        
        GridPane ROW3 = new GridPane();
        ROW3.setHgap(5);
        ROW3.setVgap(5);
        ROW3.add(lbEnterAnswer,0,0);
        ROW3.add(tf,0,1);
        ROW3.add(btnSubmit,0,2);
        ROW3.add(ta,0,3);
        ROW3.add(btnExit,0,4);
        ROW3.setAlignment(Pos.CENTER);
        lbEnterAnswer.setPadding(new Insets(0,0,0,160));
    
        btnSubmit.setPrefWidth(390);
        btnExit.setPrefWidth(390);
        btnGetQuestion.setDisable(true);
        
        
        
        
        btnGetQuestion.setOnAction(new GetQuestion());
        btnStart.setOnAction((ActionEvent event) -> {
            startTask();
            btnStart.setDisable(true);
            btnGetQuestion.setDisable(false);
        });
        btnSubmit.setOnAction(new Submit());
        btnExit.setOnAction(new Exit());
        
        BorderPane HOST = new BorderPane();
        HOST.setTop(ROW1);
        HOST.setCenter(ROW2);
        HOST.setBottom(ROW3);
        
        GridPane HOST2 = new GridPane();
        HOST2.setHgap(5);
        HOST2.setVgap(5);
        HOST2.add(lbAnswerQ,0,0);
        HOST2.add(tfAQ,1,0);
        HOST2.add(lbCorrectA,0,1);
        HOST2.add(tfCA,1,1);
        HOST2.setAlignment(Pos.CENTER);
        tfCA.setEditable(false);
        tfAQ.setEditable(false);
        
        
        
        
         //create a scene and place it in the stage
    	scene1 = new Scene(HOST,380,355);//add pane to scene
        scene2 = new Scene(HOST2);
    	Window.setTitle("Math Quiz Panel");//set the stage title
    	Window.setScene(scene1); //place the scene in the stage
    	Window.show();//display the stage
    }
    
    public static void main(String[]args){
        Application.launch(args);
    }
    
    public void startTask(){
	// Create a Runnable
	Runnable task = new Runnable(){
            public void run(){
		runTask();
            }
	};

	// Run the task in a background thread
	Thread backgroundThread = new Thread(task);
	// Terminate the running thread if the application exits
	backgroundThread.setDaemon(true);
	// Start the thread
	backgroundThread.start();
	}
    public void runTask(){
	for(int i = 20; i >=0; i--){
            try{
		// Get the Status
		final String status = "Count Down " + i ;
                // Update the Label on the JavaFx Application Thread
		Platform.runLater(new Runnable(){
		    public void run(){
		        lbCountDown.setText(status);
		    }
	        });			
                Thread.sleep(1000);
            }catch (InterruptedException e){
		e.printStackTrace();
            }
	}
        btnStart.setDisable(false);
        btnGetQuestion.setDisable(true);
        Platform.runLater(new Runnable(){
		    public void run(){
		        Window.setScene(scene2);
                        printResult();
                         
		    }
	        });    
    }
    public void printQuestion(){
      try{
      	String filename="QuizResult.txt";
      	File file = new File(filename);
      	
      	PrintWriter p = new PrintWriter(new FileWriter(file,true));//append
      	
      	p.println(AProblem.getOp1() + "\t" + AProblem.getOperator() + "\t" + AProblem.getOp2() + "\t= Your answer\t" +ans 
                + "\tCorrect Answer\t" +AProblem.getAnswer()
                );
      	
      	p.close();
      }catch(IOException e){
      	System.out.println("Exception caught: " + e.getMessage());
      }//end try
    }
    public void printResult(){
        try{
            String filename="QuizResult.txt";
            File file = new File(filename);
            PrintWriter p = new PrintWriter(new FileWriter(file,true));//append
            p.println("==============================================================");
            p.println("Answered Question : " +answerQuestion);
            p.println("Correct Answer    : " +correctAnswer);
            p.println("==============================================================");
            p.close();
        }catch(IOException e){
      	System.out.println("Exception caught: " + e.getMessage());
        }
    }
    class GetQuestion implements EventHandler<ActionEvent>{
        public void handle(ActionEvent e){
            if(rbAddition.isSelected()){
                AProblem= new AProblem('+');
                lbAProblem.setText(AProblem.toString());
            }
            else if(rbSubtraction.isSelected()){
                AProblem= new AProblem('-');
                lbAProblem.setText(AProblem.toString());
            }
            else if(rbMultiplication.isSelected()){
                AProblem= new AProblem('*');
                lbAProblem.setText(AProblem.toString());
            }
            else if(rbDivision.isSelected()){
                AProblem= new AProblem('/');
                lbAProblem.setText(AProblem.toString());
            }
            tf.setText("");
            ta.setText("");
        }
    }
    class Submit implements EventHandler<ActionEvent>{
        public void handle(ActionEvent e){
            try{
                ans=Integer.parseInt(tf.getText() );
                printQuestion();
                if(ans == AProblem.getAnswer()){
                    ta.setText("You are correct!");
                    tf.setText("");
                    answerQuestion++;
                    correctAnswer++;
                    tfCA.setText(correctAnswer+"");
                    tfAQ.setText(answerQuestion+"");
                    
                }
                else{
                    ta.setText("You are wrong! The correct answer is " +AProblem.getAnswer());
                    tf.setText("");
                    answerQuestion++;
                    tfAQ.setText(answerQuestion+"");
                }
            
            }
            catch(NumberFormatException a){
                 Alert alert = new Alert(Alert.AlertType.ERROR);
                 alert.setTitle("Invalid data");
                 alert.setHeaderText("");
                 alert.setContentText("Insert Number Only");    		
                 alert.showAndWait();
                 tf.setText("");
            
            }
                
        }
    }
    class Exit implements EventHandler<ActionEvent>{
        public void handle(ActionEvent e){
        System.exit(1);
        }
    }
    
    
   
}
