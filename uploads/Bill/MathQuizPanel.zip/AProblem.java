/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mytruehomework;

/**
 *
 * @author User
 */
public class AProblem {
    private int op1,op2;
    private char operator;
    private int id;
    
    public AProblem(){}
    public int getOp1(){
        return op1;
    }
    public int getOp2(){
        return op2;
    }
    public char getOperator(){
        return operator;
    }
    public AProblem(char operator){
        op1 = (int)(1+Math.random()*20);
        op2 = (int)(1+Math.random()*20);
        this.operator = operator;
    }
    
    public int getAnswer(){
        int answer = 0;
        switch (operator) {
            case '+':
                answer = op1 + op2;
                break;
            case '-':
                answer = op1 - op2;
                break;
            case '*':
                answer = op1 * op2;
                break;
            case '/':
                answer = op1 / op2;
                break;
            default:
                break;
        }
        return answer;
    }
    
    public String toString(){
        return "Question: "+ op1 + operator + op2 + "=??";
    }
    
}
